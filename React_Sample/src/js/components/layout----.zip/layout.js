import React from "react";
import Header from "./Header"
import Footer from "./Footer"
import LandingPage from "../pages/LandingPage"
import {Link} from "react-router";

export default class Layout extends React.Component{

	constructor(){
		super();
		this.state={title:"Pradeep2"};
	}
	
	changeTitle(title){
			this.setState({title});
		}
	
	render(){
		return (
			<div>
				<h1>Welcome to React world</h1>
				<Link>About</Link>
				// <Header changeTitle={this.changeTitle.bind(this)} title={this.state.title}/>
				// {this.state.name}
				// <LandingPage/>
				// <Footer/>
			</div>

			);
	}
}