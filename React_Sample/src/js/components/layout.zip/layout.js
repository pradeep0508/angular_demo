import React from "react";
import Header from "./Header"
import Footer from "./Footer"
import LandingPage from "../pages/LandingPage"
import {Link} from "react-router";

export default class Layout extends React.Component{

	constructor(){
		super();
	}
	render(){
		return (
			<div>
				<h1>Welcome to React world</h1>
				{this.props.childran}
				<Link to="about">About</Link>
			</div>
			);
	}
}